# WebProg_Proj2
Pre-setup for Proj 2

refer to figma for in detail tasks

#bang 11/7 - 11/8:
php logic for questions and lifeline and name input

#Siddhant 11/09 - 11/10:
php logic for the remaining two lifelines

#Daniel 11/09 - 11/10
php logic for randomized question and answer order

